package main

import (
	"flag"
	"fmt"
	"strings"
)

// CommandModel ...
type CommandModel struct {
	execDir     string
	xcworkspace string
	xcproject   string
	scheme      string
	derivedPath string
	outPath     string
}

func (c *CommandModel) IsValid() bool {
	if c.IsBuildWorkspace() == false && c.IsBuildProject() == false {
		return false
	}
	if c.IsSchemeValid() == false {
		return false
	}
	return true
}

func (c *CommandModel) IsBuildWorkspace() bool {
	return len(c.xcworkspace) > 0
}

func (c *CommandModel) IsBuildProject() bool {
	return len(c.xcproject) > 0
}

func (c *CommandModel) IsSchemeValid() bool {
	return len(c.scheme) > 0
}

func (c *CommandModel) ExecDir() string {
	return c.execDir
}

func (c *CommandModel) XCworkspace() string {
	return strings.Join([]string{c.execDir, c.xcworkspace}, "/")
}

func (c *CommandModel) XCproject() string {
	return strings.Join([]string{c.execDir, c.xcproject}, "/")
}

func (c *CommandModel) Scheme() string {
	return c.scheme
}

func (c *CommandModel) DerivedPath() string {
	return strings.Join([]string{c.execDir, c.derivedPath}, "/")
}

func (c *CommandModel) OutPath() string {
	return strings.Join([]string{c.execDir, c.outPath}, "/")
}

func (c *CommandModel) Parse(args []string) {
	xcworkspace := flag.String("xcworkspace", "", "Define a Xcode workspace file to build.")
	xcproj := flag.String("xcproject", "", "Define a Xcode project file to build.")
	scheme := flag.String("scheme", "", "Scheme settings for building.")

	flag.Parse()

	c.xcworkspace = *xcworkspace
	c.xcproject = *xcproj
	c.scheme = *scheme
}

func (c *CommandModel) description() {
	if len(c.execDir) != 0 {
		fmt.Println(c.ExecDir())
	}

	if len(c.xcworkspace) != 0 {
		fmt.Println(c.XCworkspace())
	}

	if len(c.xcproject) != 0 {
		fmt.Println(c.XCproject())
	}

	if len(c.derivedPath) != 0 {
		fmt.Println(c.DerivedPath())
	}

	if len(c.outPath) != 0 {
		fmt.Println(c.OutPath())
	}
}
