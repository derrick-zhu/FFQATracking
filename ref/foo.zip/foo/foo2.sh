echo hello from foo2
