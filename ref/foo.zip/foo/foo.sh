#!/bin/sh

echo "hello from bash"
